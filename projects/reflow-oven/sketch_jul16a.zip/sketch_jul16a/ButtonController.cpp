#include "ButtonController.h"

#define DEBOUNCE_COOLDOWN_MS  500

uint8_t Button::nButtons = 0;
bool Button::activatedFlags[32];

Button::Button(uint8_t pin) {
  this->gpio = pin;
  pinMode(pin, INPUT_PULLUP);
  this->activatedFlag = false;
  this->previousActivation = millis();
  Button::activatedFlags[nButtons] = false;
  Button::nButtons++;
}

void Button::check() {
  if ((!digitalRead(this->gpio)) && (millis() > this->previousActivation + DEBOUNCE_COOLDOWN_MS)) {
    this->previousActivation = millis();
    this->activatedFlag = true;
    Button::activatedFlags[nButtons - 1] = true;
  }
}

bool Button::getState() {
  bool returnVal = this->activatedFlag;
  this->activatedFlag = false;
  Button::activatedFlags[nButtons - 1] = false;
  return returnVal;
}

bool Button::getGlobalState() {
  bool value = false;
  for (uint8_t i = 0; i < this->nButtons; i++) {
    value |= Button::activatedFlags[i];
  }
  return value;
}
