#include "Arduino.h"


bool AddTask(void (*function)(), uint16_t delay);
void UpdateTasks();
void ClearTasks();
