#include "Arduino.h"


class Button {
  uint8_t gpio;
  uint32_t previousActivation;
  bool activatedFlag;
  static bool globalActivatedFlag;
  static bool activatedFlags[];
  static uint8_t nButtons;
  public:
  Button(uint8_t pin);
  bool getState();
  bool getGlobalState();
  void check();
  // getState flag is cleared when it is read, and then there is the cooldown.
};
